help of Vsearch
